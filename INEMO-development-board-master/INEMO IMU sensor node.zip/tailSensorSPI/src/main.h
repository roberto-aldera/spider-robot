/*
 * main.h
 *
 *  Created on: Nov 27, 2014
 *      Author: Callen Fisher
 */

#ifndef MAIN_H_
#define MAIN_H_


uint16_t dum;
uint16_t recVal;
//float acc[3];
//float mag[3];
//float gyro[3];
//s8 temp;
int p;
uint8_t acc8[6];
uint8_t mag8[6];
uint8_t gyro8[6];
uint8_t temp8[2];

#endif /* MAIN_H_ */
