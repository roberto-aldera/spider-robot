/*
 * controlLoopTimer.c
 *
 *  Created on: Jun 6, 2014
 *      Author: Callen Fisher
 */

#include "controlLoopTimer.h"



//void resetTimInt()
//{
//	proceed=0;
//}
//
//void wait(void)
//{
//	while(proceed==0)
//	{
//		if(DMA_GetFlagStatus(DMA1_FLAG_TC7))
//		{
//			proceed=1;
//			DMA_ClearFlag(DMA1_FLAG_TC7);
//		}
//	}
//	proceed=0;
//}
